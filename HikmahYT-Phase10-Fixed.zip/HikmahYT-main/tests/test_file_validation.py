"""Tests for completed-download output verification."""
import tempfile
import unittest
from pathlib import Path

from utils.file_validation import validate_output_file


class OutputValidationTests(unittest.TestCase):
    def test_existing_nonempty_file_is_valid(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "video.mp4"
            target.write_bytes(b"media")
            self.assertEqual(validate_output_file(target), (True, ""))

    def test_missing_file_is_invalid(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "missing.mp4"
            valid, reason = validate_output_file(target)
            self.assertFalse(valid)
            self.assertIn("not found", reason)

    def test_empty_file_is_invalid(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / "empty.mp4"
            target.touch()
            valid, reason = validate_output_file(target)
            self.assertFalse(valid)
            self.assertIn("empty", reason)

    def test_directory_is_invalid(self):
        with tempfile.TemporaryDirectory() as folder:
            valid, reason = validate_output_file(folder)
            self.assertFalse(valid)
            self.assertIn("not a file", reason)

    def test_empty_path_is_unverifiable_not_failed(self):
        self.assertEqual(validate_output_file(""), (True, ""))


if __name__ == "__main__":
    unittest.main()
