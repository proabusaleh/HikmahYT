"""Mocked integration tests for end-to-end yt-dlp engine orchestration.

These tests exercise the engine's real option-building and fallback paths without
network access or an actual media download. Live site/Windows QA remains manual.
"""
import sys
import types
import unittest
from unittest.mock import patch

# Keep this suite runnable in minimal test environments without yt-dlp installed.
if 'yt_dlp' not in sys.modules:
    fake_yt_dlp = types.ModuleType('yt_dlp')
    fake_yt_dlp.utils = types.SimpleNamespace(
        DownloadCancelled=type('DownloadCancelled', (Exception,), {})
    )
    fake_yt_dlp.YoutubeDL = object
    sys.modules['yt_dlp'] = fake_yt_dlp

import downloader
from downloader import DownloadEngine


class FakeYoutubeDL:
    calls = []
    results = []

    def __init__(self, options):
        self.options = options
        self.result = self.results.pop(0) if self.results else 0
        self.calls.append((options, self.result))

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def download(self, urls):
        self.urls = urls
        if isinstance(self.result, Exception):
            raise self.result
        return self.result


class DownloadEngineIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.engine = DownloadEngine()
        FakeYoutubeDL.calls = []
        FakeYoutubeDL.results = []
        self.youtube_dl_patch = patch.object(downloader.yt_dlp, 'YoutubeDL', FakeYoutubeDL)
        self.youtube_dl_patch.start()
        self.addCleanup(self.youtube_dl_patch.stop)
        self.base_opts_patch = patch('downloader.base_ydl_opts', side_effect=lambda **kw: dict(kw))
        self.base_opts_patch.start()
        self.addCleanup(self.base_opts_patch.stop)
        self.settings_patch = patch.object(self.engine, '_apply_settings')
        self.settings_patch.start()
        self.addCleanup(self.settings_patch.stop)

    def video_params(self, **overrides):
        params = {
            'url': 'https://example.test/watch?v=abc',
            'format_id': 'best', 'audio_only': False, 'quality': '720',
            'container': '', 'audio_codec': 'mp3', 'download_thumb': False,
            'embed_meta': False, 'download_subs': False, 'subs_langs': 'en',
            'embed_subs': False, 'codec': '', 'hdr': False, 'fps60': False,
            'sub_format': '', 'write_json': False, 'archive': False,
            'match_filters': None, 'playlist': False,
        }
        params.update(overrides)
        return params

    def test_video_success_passes_url_and_format_options(self):
        self.engine._build_attempts = lambda *args: ['bestvideo+bestaudio/best']
        self.engine._run_video('task-1', self.video_params(container='mp4', write_json=True))
        self.assertEqual(len(FakeYoutubeDL.calls), 1)
        options, _ = FakeYoutubeDL.calls[0]
        self.assertEqual(options['format'], 'bestvideo+bestaudio/best')
        self.assertEqual(options['merge_output_format'], 'mp4')
        self.assertTrue(options['writeinfojson'])

    def test_video_nonzero_return_uses_fallback_format(self):
        self.engine._build_attempts = lambda *args: ['high-quality', 'combined']
        FakeYoutubeDL.results = [1, 0]
        errors = []
        self.engine.set_callback('on_error', lambda message, task_id: errors.append((message, task_id)))
        self.engine._run_video('task-2', self.video_params())
        self.assertEqual([call[0]['format'] for call in FakeYoutubeDL.calls], ['high-quality', 'combined'])
        self.assertEqual(errors, [])

    def test_video_reports_error_when_all_formats_fail(self):
        self.engine._build_attempts = lambda *args: ['first', 'second']
        FakeYoutubeDL.results = [2, 3]
        errors = []
        self.engine.set_callback('on_error', lambda message, task_id: errors.append((message, task_id)))
        self.engine._run_video('task-3', self.video_params())
        self.assertEqual(len(errors), 1)
        self.assertIn('status 3', errors[0][0])
        self.assertEqual(errors[0][1], 'task-3')

    def test_playlist_selected_indices_are_passed_to_yt_dlp(self):
        params = self.video_params(selected_indices=[2, 4, 7], playlist=True)
        self.engine._build_attempts = lambda *args: ['best']
        self.engine._run_playlist('playlist-1', params)
        options, _ = FakeYoutubeDL.calls[0]
        self.assertEqual(options['playlist_items'], '2,4,7')

    def test_playlist_range_takes_precedence_over_selected_indices(self):
        params = self.video_params(selected_indices=[2, 4], range_str='5-9', playlist=True)
        self.engine._build_attempts = lambda *args: ['best']
        self.engine._run_playlist('playlist-2', params)
        options, _ = FakeYoutubeDL.calls[0]
        self.assertEqual(options['playlist_items'], '5-9')


if __name__ == '__main__':
    unittest.main()
