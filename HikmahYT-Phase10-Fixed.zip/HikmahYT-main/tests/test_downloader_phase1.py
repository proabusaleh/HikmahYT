"""Regression tests for Phase 1 download-engine fixes.

Run with: python -m unittest discover -s tests -v
"""
import sys
import types
import unittest
from unittest.mock import patch

# The engine's pure unit tests do not need yt-dlp installed. Provide the small
# API surface imported by downloader.py; integration tests should use the real dependency.
if 'yt_dlp' not in sys.modules:
    fake_yt_dlp = types.ModuleType('yt_dlp')
    fake_yt_dlp.utils = types.SimpleNamespace(
        DownloadCancelled=type('DownloadCancelled', (Exception,), {})
    )
    fake_yt_dlp.YoutubeDL = object
    sys.modules['yt_dlp'] = fake_yt_dlp

from downloader import DownloadEngine


class DownloadEnginePhase1Tests(unittest.TestCase):
    def setUp(self):
        self.engine = DownloadEngine()

    def test_metadata_does_not_force_thumbnail_embedding(self):
        processors = self.engine._build_postprocessors({
            'embed_meta': True,
            'download_thumb': False,
            'audio_only': False,
        })
        keys = [item['key'] for item in processors]
        self.assertNotIn('EmbedThumbnail', keys)
        self.assertNotIn('FFmpegThumbnailsConvertor', keys)

    def test_download_thumbnail_adds_thumbnail_conversion(self):
        processors = self.engine._build_postprocessors({
            'embed_meta': False,
            'download_thumb': True,
            'audio_only': False,
        })
        self.assertIn('FFmpegThumbnailsConvertor', [p['key'] for p in processors])

    def test_explicit_embed_thumbnail_adds_embed_postprocessor(self):
        processors = self.engine._build_postprocessors({
            'embed_meta': False,
            'download_thumb': False,
            'embed_thumbnail': True,
            'audio_only': False,
        })
        self.assertIn('EmbedThumbnail', [p['key'] for p in processors])

    def test_worker_is_registered_before_start(self):
        observed = []
        engine = self.engine

        class ImmediateThread:
            def __init__(self, target, args, **kwargs):
                self.target = target
                self.args = args
                self.started = False
            def start(self):
                self.started = True
                observed.append(engine.active_downloads.get('task') is self)
            def is_alive(self):
                return self.started

        self.engine._task_params['task'] = {'url': 'https://example.com', 'playlist': False}
        with patch('downloader.threading.Thread', ImmediateThread):
            thread = self.engine._spawn_worker('task')
        self.assertIs(thread, self.engine.active_downloads['task'])
        self.assertEqual(observed, [True])

    def test_find_active_task_detects_same_url_with_trailing_slash(self):
        class AliveThread:
            def is_alive(self):
                return True

        self.engine._task_params["task-1"] = {"url": "https://example.com/video/", "playlist": False}
        self.engine.active_downloads["task-1"] = AliveThread()
        self.engine._cancel_flags["task-1"] = False
        self.assertEqual(self.engine.find_active_task(" https://example.com/video "), "task-1")

    def test_find_active_task_ignores_completed_and_cancelled_tasks(self):
        class AliveThread:
            def is_alive(self):
                return True

        self.engine._task_params["done"] = {"url": "https://example.com/done", "playlist": False}
        self.engine.active_downloads["done"] = AliveThread()
        self.engine._completed.add("done")
        self.engine._task_params["cancelled"] = {"url": "https://example.com/cancelled", "playlist": False}
        self.engine.active_downloads["cancelled"] = AliveThread()
        self.engine._cancel_flags["cancelled"] = True
        self.assertIsNone(self.engine.find_active_task("https://example.com/done"))
        self.assertIsNone(self.engine.find_active_task("https://example.com/cancelled"))

    def test_find_active_task_preserves_query_strings(self):
        class AliveThread:
            def is_alive(self):
                return True

        self.engine._task_params["signed"] = {"url": "https://example.com/file?token=one", "playlist": False}
        self.engine.active_downloads["signed"] = AliveThread()
        self.engine._cancel_flags["signed"] = False
        self.assertIsNone(self.engine.find_active_task("https://example.com/file?token=two"))

    def test_cancel_wakes_slot_waiters(self):
        self.engine.max_concurrent = 1
        self.engine._active_count = 1
        self.engine._cancel_flags['queued'] = False
        self.engine.cancel_download('queued')
        self.assertTrue(self.engine._cancel_flags['queued'])

    def test_progress_is_clamped_to_valid_percentage(self):
        received = []
        self.engine.set_callback('on_progress', received.append)
        self.engine._progress_hook({
            'status': 'downloading',
            'downloaded_bytes': 150,
            'total_bytes': 100,
            'speed': 1,
            'eta': 1,
            'filename': 'video.mp4',
        }, 'task')
        self.assertEqual(received[0]['progress'], 100.0)

    def test_unknown_progress_size_is_safe(self):
        received = []
        self.engine.set_callback('on_progress', received.append)
        self.engine._progress_hook({
            'status': 'downloading',
            'downloaded_bytes': None,
            'total_bytes': None,
            'filename': 'video.mp4',
        }, 'task')
        self.assertEqual(received[0]['progress'], 0.0)


if __name__ == '__main__':
    unittest.main()
