"""Regression checks for release metadata consistency."""
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERSION = "6.1.0"
ZIP_NAME = f"HikmahYT-v{VERSION}-win64.zip"


class ReleaseConfigTests(unittest.TestCase):
    def test_app_and_windows_version_match(self):
        ui = (ROOT / "ui/main_window.py").read_text(encoding="utf-8")
        resource = (ROOT / "version_info.txt").read_text(encoding="utf-8")
        build = (ROOT / "build.bat").read_text(encoding="utf-8")
        self.assertRegex(ui, rf'APP_VERSION\s*=\s*"{re.escape(VERSION)}"')
        self.assertIn("filevers=(6, 1, 0, 0)", resource)
        self.assertIn("prodvers=(6, 1, 0, 0)", resource)
        self.assertIn(f"set VERSION={VERSION}", build)

    def test_artifact_name_matches_docs_and_ci(self):
        build = (ROOT / "build.bat").read_text(encoding="utf-8")
        readme = (ROOT / "README.md").read_text(encoding="utf-8")
        workflow = (ROOT / ".github/workflows/build-release.yml").read_text(encoding="utf-8")
        self.assertIn(f"set ZIP_NAME={ZIP_NAME}", build)
        self.assertIn(ZIP_NAME, readme)
        self.assertIn(ZIP_NAME, workflow)

    def test_build_only_dependencies_are_separate(self):
        runtime = (ROOT / "requirements.txt").read_text(encoding="utf-8")
        build = (ROOT / "requirements-build.txt").read_text(encoding="utf-8")
        self.assertNotIn("pyinstaller==", runtime)
        self.assertIn("pyinstaller==", build)


if __name__ == "__main__":
    unittest.main()
