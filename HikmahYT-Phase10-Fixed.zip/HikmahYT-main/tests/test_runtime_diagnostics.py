"""Unit tests for runtime diagnostics; never touches the network."""
import importlib.util
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "diagnose_runtime.py"
SPEC = importlib.util.spec_from_file_location("diagnose_runtime", SCRIPT)
module = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(module)


class RuntimeDiagnosticsTests(unittest.TestCase):
    def test_report_contains_expected_sections(self):
        with patch.object(module, "_check_writable_directory", return_value=(True, "writable")), \
             patch.object(module, "_distribution_version", return_value="1.2.3"), \
             patch.object(module.shutil, "which", return_value="/usr/bin/ffmpeg"):
            report = module.collect_diagnostics()
        self.assertEqual(report["app_version"], "6.1.0")
        self.assertIn("checks", report)
        self.assertTrue(report["checks"]["required_packages_installed"])
        self.assertTrue(report["checks"]["ffmpeg_available"])
        self.assertEqual(len(report["limitations"]), 3)

    def test_missing_dependency_is_reported(self):
        with patch.object(module, "_check_writable_directory", return_value=(True, "writable")), \
             patch.object(module, "_distribution_version", side_effect=[None, "1", "1", "1", "1", "1"]), \
             patch.object(module.shutil, "which", return_value="/usr/bin/ffmpeg"):
            report = module.collect_diagnostics()
        self.assertFalse(report["checks"]["required_packages_installed"])
        self.assertFalse(report["all_checks_passed"])

    def test_directory_check_creates_and_tests_write_access(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            target = Path(temp_dir) / "nested" / "downloads"
            ok, detail = module._check_writable_directory(target)
        self.assertTrue(ok)
        self.assertIn("writable", detail.lower())


if __name__ == "__main__":
    unittest.main()
