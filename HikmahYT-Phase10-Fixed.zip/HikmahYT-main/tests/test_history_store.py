"""Tests for SQLite download history and restart recovery."""
import tempfile
import unittest
from pathlib import Path

from utils.history_store import DownloadHistoryStore


class DownloadHistoryStoreTests(unittest.TestCase):
    def setUp(self):
        self.tempdir = tempfile.TemporaryDirectory()
        self.db = Path(self.tempdir.name) / "history.sqlite3"
        self.store = DownloadHistoryStore(self.db)

    def tearDown(self):
        self.tempdir.cleanup()

    def test_upsert_and_reload_params(self):
        self.store.upsert("task-1", title="Example", url="https://example.com/v",
                          status="downloading", progress=22.5, params={"quality": "720"})
        reloaded = DownloadHistoryStore(self.db).get("task-1")
        self.assertEqual(reloaded["title"], "Example")
        self.assertEqual(reloaded["progress"], 22.5)
        self.assertEqual(reloaded["params"], {"quality": "720"})

    def test_progress_is_clamped(self):
        self.store.upsert("task", progress=200)
        self.assertEqual(self.store.get("task")["progress"], 100.0)
        self.store.upsert("task", progress=-10)
        self.assertEqual(self.store.get("task")["progress"], 0.0)

    def test_inflight_tasks_marked_interrupted_but_completed_kept(self):
        self.store.upsert("active", status="downloading")
        self.store.upsert("paused", status="paused")
        self.store.upsert("done", status="completed", progress=100)
        changed = self.store.mark_interrupted()
        self.assertEqual(changed, 2)
        self.assertEqual(self.store.get("active")["status"], "interrupted")
        self.assertEqual(self.store.get("paused")["status"], "interrupted")
        self.assertEqual(self.store.get("done")["status"], "completed")

    def test_delete_removes_record_without_affecting_other_records(self):
        self.store.upsert("keep", status="completed")
        self.store.upsert("remove", status="error")
        self.assertTrue(self.store.delete("remove"))
        self.assertIsNone(self.store.get("remove"))
        self.assertIsNotNone(self.store.get("keep"))
        self.assertFalse(self.store.delete("remove"))

    def test_clear_can_be_limited_to_statuses(self):
        self.store.upsert("done", status="completed")
        self.store.upsert("failed", status="error")
        self.assertEqual(self.store.clear(statuses=["error"]), 1)
        self.assertIsNotNone(self.store.get("done"))
        self.assertIsNone(self.store.get("failed"))

    def test_newest_records_listed_first(self):
        self.store.upsert("a", title="Old")
        self.store.upsert("b", title="New")
        self.assertEqual(len(self.store.list_all()), 2)
        self.assertEqual({x["task_id"] for x in self.store.list_all()}, {"a", "b"})


if __name__ == "__main__":
    unittest.main()
