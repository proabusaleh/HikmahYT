"""Tests for the release ZIP verifier using temporary synthetic archives."""
import tempfile
import unittest
import zipfile
from pathlib import Path

from scripts.verify_release_artifact import inspect_archive


class ReleaseArtifactTests(unittest.TestCase):
    def make_archive(self, root, members):
        archive_path = Path(root) / "release.zip"
        with zipfile.ZipFile(archive_path, "w") as archive:
            for name, content in members.items():
                archive.writestr(name, content)
        return archive_path

    def test_valid_archive_layout_passes(self):
        with tempfile.TemporaryDirectory() as temp:
            archive = self.make_archive(temp, {
                "HikmahYT.exe": b"fake exe",
                "_internal/python.dll": b"fake runtime",
                "_internal/ffmpeg-win64.exe": b"fake ffmpeg",
            })
            self.assertEqual(inspect_archive(archive), [])

    def test_missing_executable_and_runtime_are_reported(self):
        with tempfile.TemporaryDirectory() as temp:
            archive = self.make_archive(temp, {"README.md": "test"})
            errors = inspect_archive(archive)
            self.assertTrue(any("HikmahYT.exe" in error for error in errors))
            self.assertTrue(any("_internal" in error for error in errors))

    def test_missing_ffmpeg_is_reported(self):
        with tempfile.TemporaryDirectory() as temp:
            archive = self.make_archive(temp, {
                "HikmahYT.exe": b"fake exe",
                "_internal/python.dll": b"fake runtime",
            })
            self.assertTrue(any("ffmpeg" in error.lower() for error in inspect_archive(archive)))

    def test_path_traversal_is_reported(self):
        with tempfile.TemporaryDirectory() as temp:
            archive = self.make_archive(temp, {
                "HikmahYT.exe": b"fake exe",
                "_internal/python.dll": b"fake runtime",
                "_internal/ffmpeg.exe": b"fake ffmpeg",
                "../outside.txt": b"unsafe",
            })
            self.assertTrue(any("Unsafe archive path" in error for error in inspect_archive(archive)))

    def test_missing_archive_is_reported(self):
        with tempfile.TemporaryDirectory() as temp:
            errors = inspect_archive(Path(temp) / "missing.zip")
            self.assertTrue(any("does not exist" in error for error in errors))


if __name__ == "__main__":
    unittest.main()
