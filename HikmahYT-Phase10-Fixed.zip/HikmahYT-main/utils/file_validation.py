"""Output-file checks used before reporting a download as complete."""
from pathlib import Path


def validate_output_file(path):
    """Return ``(ok, reason)`` for a downloaded output path.

    Empty paths are treated as unverifiable rather than failed, since playlist
    operations may report completion without a single top-level output file.
    Never deletes files: zero-byte or partial files are left for diagnosis or
    yt-dlp's normal continuation behavior.
    """
    if not path:
        return True, ""
    try:
        target = Path(path).expanduser()
        if not target.exists():
            return False, f"Output file was not found: {target}"
        if not target.is_file():
            return False, f"Output path is not a file: {target}"
        if target.stat().st_size <= 0:
            return False, f"Output file is empty: {target}"
    except (OSError, ValueError) as exc:
        return False, f"Unable to verify output file: {exc}"
    return True, ""
