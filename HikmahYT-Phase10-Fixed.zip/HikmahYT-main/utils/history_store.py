"""SQLite-backed download history for HikmahYT.

The database lives in the user's application-data directory, not beside the
executable, so installed builds can persist history without admin permissions.
"""
from __future__ import annotations

import json
import os
import sqlite3
import tempfile
import threading
from datetime import datetime, timezone
from pathlib import Path


def default_database_path() -> Path:
    if os.name == "nt":
        root = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
    else:
        root = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share")
    return root / "HikmahYT" / "history.sqlite3"


class DownloadHistoryStore:
    """Small thread-safe repository for durable task metadata and status."""

    def __init__(self, database_path=None):
        self.database_path = Path(database_path) if database_path else default_database_path()
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._initialize()

    def _connect(self):
        connection = sqlite3.connect(str(self.database_path), timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA busy_timeout=10000")
        return connection

    def _initialize(self):
        with self._lock, self._connect() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.execute("""CREATE TABLE IF NOT EXISTS downloads (
                task_id TEXT PRIMARY KEY, title TEXT NOT NULL DEFAULT '',
                url TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'pending',
                progress REAL NOT NULL DEFAULT 0, output_path TEXT NOT NULL DEFAULT '',
                error_message TEXT NOT NULL DEFAULT '', params_json TEXT NOT NULL DEFAULT '{}',
                created_at TEXT NOT NULL, updated_at TEXT NOT NULL
            )""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_downloads_updated ON downloads(updated_at DESC)")

    @staticmethod
    def _now():
        return datetime.now(timezone.utc).isoformat(timespec="seconds")

    def upsert(self, task_id, *, title='', url='', status='pending', progress=0,
               output_path='', error_message='', params=None):
        now = self._now()
        try:
            progress = min(100.0, max(0.0, float(progress or 0)))
        except (TypeError, ValueError, OverflowError):
            progress = 0.0
        params_json = json.dumps(params or {}, ensure_ascii=False, default=str)
        with self._lock, self._connect() as db:
            db.execute("""INSERT INTO downloads
                (task_id,title,url,status,progress,output_path,error_message,params_json,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(task_id) DO UPDATE SET
                  title=CASE WHEN excluded.title='' THEN downloads.title ELSE excluded.title END,
                  url=CASE WHEN excluded.url='' THEN downloads.url ELSE excluded.url END,
                  status=excluded.status, progress=excluded.progress,
                  output_path=CASE WHEN excluded.output_path='' THEN downloads.output_path ELSE excluded.output_path END,
                  error_message=excluded.error_message,
                  params_json=CASE WHEN excluded.params_json='{}' THEN downloads.params_json ELSE excluded.params_json END,
                  updated_at=excluded.updated_at""",
                (str(task_id), title or '', url or '', status, progress, output_path or '',
                 error_message or '', params_json, now, now))

    def get(self, task_id):
        with self._lock, self._connect() as db:
            row = db.execute("SELECT * FROM downloads WHERE task_id=?", (str(task_id),)).fetchone()
        return self._decode(row) if row else None

    def list_all(self, limit=500):
        with self._lock, self._connect() as db:
            rows = db.execute("SELECT * FROM downloads ORDER BY updated_at DESC LIMIT ?",
                              (max(1, min(int(limit), 5000)),)).fetchall()
        return [self._decode(row) for row in rows]

    def mark_interrupted(self):
        """Convert in-flight records from a previous run to resumable candidates."""
        now = self._now()
        with self._lock, self._connect() as db:
            cursor = db.execute("""UPDATE downloads SET status='interrupted',
                error_message='App closed before the download finished', updated_at=?
                WHERE status IN ('pending','downloading','paused')""", (now,))
            return cursor.rowcount


    def delete(self, task_id):
        """Delete one history record; does not delete the downloaded file."""
        with self._lock, self._connect() as db:
            cursor = db.execute("DELETE FROM downloads WHERE task_id=?", (str(task_id),))
            return cursor.rowcount > 0

    def clear(self, statuses=None):
        """Clear history records, optionally restricted to a set of statuses."""
        with self._lock, self._connect() as db:
            if not statuses:
                cursor = db.execute("DELETE FROM downloads")
            else:
                values = tuple(str(value) for value in statuses)
                placeholders = ",".join("?" for _ in values)
                cursor = db.execute(
                    f"DELETE FROM downloads WHERE status IN ({placeholders})", values
                )
            return cursor.rowcount

    @staticmethod
    def _decode(row):
        item = dict(row)
        try:
            item['params'] = json.loads(item.pop('params_json') or '{}')
        except (ValueError, TypeError):
            item['params'] = {}
            item.pop('params_json', None)
        return item
