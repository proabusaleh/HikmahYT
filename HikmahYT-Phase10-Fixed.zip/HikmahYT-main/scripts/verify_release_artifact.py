"""Verify the distributable ZIP created by build.bat.

Usage: python scripts/verify_release_artifact.py [path-to-zip]
The verifier is intentionally static: it validates archive integrity and layout,
not whether the Windows GUI or a live download works on this machine.
"""
from pathlib import Path, PurePosixPath
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ARCHIVE = ROOT / "dist" / "HikmahYT-v6.1.0-win64.zip"


def inspect_archive(archive_path):
    """Return a list of archive validation errors; an empty list means pass."""
    path = Path(archive_path)
    errors = []
    if not path.is_file():
        return [f"Archive does not exist: {path}"]

    try:
        with zipfile.ZipFile(path) as archive:
            bad_member = archive.testzip()
            if bad_member is not None:
                errors.append(f"CRC check failed for: {bad_member}")
            names = [item.filename for item in archive.infolist()]
            normalized = [PurePosixPath(name) for name in names]
            for name, parsed in zip(names, normalized):
                if parsed.is_absolute() or ".." in parsed.parts or "\\" in name:
                    errors.append(f"Unsafe archive path: {name}")
            if "HikmahYT.exe" not in names:
                errors.append("Archive is missing HikmahYT.exe at its root")
            if not any(name.startswith("_internal/") and not name.endswith("/") for name in names):
                errors.append("Archive is missing the _internal runtime folder")
            if not any(name.startswith("_internal/") and Path(name).name.lower().startswith("ffmpeg") and Path(name).suffix.lower() == ".exe" for name in names):
                errors.append("Archive does not appear to contain a bundled ffmpeg executable")
    except (OSError, zipfile.BadZipFile, RuntimeError) as exc:
        errors.append(f"Unable to inspect archive: {exc}")
    return errors


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if len(argv) > 1:
        print("Usage: python scripts/verify_release_artifact.py [path-to-zip]", file=sys.stderr)
        return 2
    archive = Path(argv[0]) if argv else DEFAULT_ARCHIVE
    errors = inspect_archive(archive)
    if errors:
        for error in errors:
            print(f"FAIL: {error}", file=sys.stderr)
        return 1
    print(f"PASS: archive integrity and required files verified: {archive}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
