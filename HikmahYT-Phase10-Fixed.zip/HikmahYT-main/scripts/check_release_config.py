"""Validate that application, Windows build, and release metadata agree.

Run with: python scripts/check_release_config.py
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_VERSION = "6.1.0"
EXPECTED_ZIP = f"HikmahYT-v{EXPECTED_VERSION}-win64.zip"

checks = {
    "UI version": (ROOT / "ui/main_window.py", rf'APP_VERSION\s*=\s*"{re.escape(EXPECTED_VERSION)}"'),
    "build script version": (ROOT / "build.bat", rf"set VERSION={re.escape(EXPECTED_VERSION)}\b"),
    "build artifact name": (ROOT / "build.bat", re.escape(f"set ZIP_NAME={EXPECTED_ZIP}")),
    "Windows file version": (ROOT / "version_info.txt", r"filevers=\(6, 1, 0, 0\)"),
    "release workflow artifact": (ROOT / ".github/workflows/build-release.yml", re.escape(EXPECTED_ZIP)),
    "README artifact name": (ROOT / "README.md", re.escape(EXPECTED_ZIP)),
}

errors = []
for label, (path, pattern) in checks.items():
    content = path.read_text(encoding="utf-8")
    if re.search(pattern, content) is None:
        errors.append(f"FAIL: {label} mismatch in {path.relative_to(ROOT)}")
    else:
        print(f"PASS: {label}")

if errors:
    print("\n".join(errors), file=sys.stderr)
    raise SystemExit(1)
print(f"Release configuration is consistent: v{EXPECTED_VERSION}")
