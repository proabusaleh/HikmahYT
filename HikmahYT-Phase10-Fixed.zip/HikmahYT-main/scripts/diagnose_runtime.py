"""Create a local, privacy-conscious runtime diagnostic report.

Usage:
  python scripts/diagnose_runtime.py
  python scripts/diagnose_runtime.py --json runtime-diagnostics.json

This checks the current Python environment. It does not launch the GUI or make
network requests, and therefore cannot certify a packaged Windows EXE.
"""
from __future__ import annotations

import argparse
import importlib.metadata
import json
import os
import platform
import shutil
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

APP_VERSION = "6.1.0"
REQUIRED_DISTRIBUTIONS = (
    "customtkinter",
    "yt-dlp",
    "Pillow",
    "requests",
    "imageio-ffmpeg",
    "pycryptodomex",
)


def _distribution_version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def _check_writable_directory(path: Path) -> tuple[bool, str]:
    try:
        path.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(prefix=".hikmahy_t_write_test_", dir=path, delete=True):
            pass
        return True, "Directory exists and is writable"
    except OSError as exc:
        return False, f"Cannot write to directory ({type(exc).__name__})"


def collect_diagnostics() -> dict:
    packages = {name: _distribution_version(name) for name in REQUIRED_DISTRIBUTIONS}
    download_dir = Path.home() / "Downloads" / "HikmahYT"
    writable, writable_detail = _check_writable_directory(download_dir)

    ffmpeg_path = shutil.which("ffmpeg")
    if not ffmpeg_path:
        try:
            import imageio_ffmpeg
            candidate = imageio_ffmpeg.get_ffmpeg_exe()
            if candidate and Path(candidate).is_file():
                ffmpeg_path = candidate
        except Exception:
            ffmpeg_path = None

    checks = {
        "python_version_supported": sys.version_info >= (3, 11),
        "required_packages_installed": all(packages.values()),
        "ffmpeg_available": bool(ffmpeg_path),
        "download_directory_writable": writable,
    }
    return {
        "app_version": APP_VERSION,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "platform": platform.platform(),
        "python_version": platform.python_version(),
        "python_executable": sys.executable,
        "frozen_executable": bool(getattr(sys, "frozen", False)),
        "packages": packages,
        "ffmpeg_path": ffmpeg_path,
        "download_directory": str(download_dir),
        "download_directory_detail": writable_detail,
        "checks": checks,
        "all_checks_passed": all(checks.values()),
        "limitations": [
            "No network requests or media downloads were performed.",
            "This report does not validate GUI startup or a packaged EXE on clean Windows.",
            "The Python executable path and platform details may contain local machine information; review before sharing.",
        ],
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Check HikmahYT runtime prerequisites.")
    parser.add_argument("--json", metavar="PATH", help="also save report as JSON to PATH")
    args = parser.parse_args(argv)
    report = collect_diagnostics()

    print(f"HikmahYT runtime diagnostics — v{report['app_version']}")
    print(f"Platform: {report['platform']}")
    print(f"Python: {report['python_version']} ({'supported' if report['checks']['python_version_supported'] else 'unsupported; project CI uses Python 3.11'})")
    for name, version in report["packages"].items():
        print(f"{'PASS' if version else 'FAIL'} package {name}: {version or 'not installed'}")
    print(f"{'PASS' if report['checks']['ffmpeg_available'] else 'WARN'} FFmpeg: {report['ffmpeg_path'] or 'not found'}")
    print(f"{'PASS' if report['checks']['download_directory_writable'] else 'FAIL'} download directory: {report['download_directory_detail']}")
    print(f"Overall prerequisite check: {'PASS' if report['all_checks_passed'] else 'NEEDS ATTENTION'}")

    if args.json:
        output_path = Path(args.json).expanduser()
        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
            print(f"JSON report saved: {output_path}")
        except OSError as exc:
            print(f"Could not write JSON report: {type(exc).__name__}: {exc}", file=sys.stderr)
            return 2
    return 0 if report["all_checks_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
