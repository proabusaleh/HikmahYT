# ▶ HikmahYT Pro - Modern Video Downloader

![Python](https://img.shields.io/badge/Python-3.10+-blue.svg)
![Version](https://img.shields.io/badge/Version-v6.1.0-orange.svg)
![License](https://img.shields.io/badge/License-MIT-green.svg)

A beautiful, modern video downloader with a smooth dark UI, playlist support,
and deep download options — powered by yt-dlp.

> **"Hikmah"** means *wisdom* in Arabic — Download with Wisdom! ✨

## ✨ Features

**Works with 1000+ sites** — YouTube, Facebook, TikTok, Instagram, X/Twitter,
Twitch, Telegram, Vimeo, Dailymotion, Reddit, Pinterest, LinkedIn, Tumblr,
Flickr, VK, Kick, Rumble, Odysee, SoundCloud, Bandcamp, Mixcloud, YouTube
Music, Internet Archive & more. Paste any URL.

- 🎬 **Full Quality Ladder** — 8K, 4K, 2K, 1080p, 720p, 480p, 360p, 240p, 144p
  plus a full per-resolution format list (size, fps, HDR labels)
- 🎥 **Codec Selection** — H.264 / H.265 / AV1 / VP9 / VP8 with hard format
  sorting
- 🌞 **HDR + 60fps** preferences
- 🎵 **Audio Extract** — MP3, AAC, M4A, OPUS, VORBIS, FLAC, ALAC, WAV
  (128–320 kbps)
- 📦 **Container Conversion** — MP4, MKV, WebM, AVI, MOV, FLV (remux, no
  re-encode)
- 💬 **Subtitles** — manual + auto captions, any language, convert to
  SRT / VTT / ASS / LRC, or embed them into the file
- 🖼 **Thumbnails + Metadata** — download/embed thumbnail, embed tags, and
  export full `.info.json` sidecar
- 📋 **Playlist & Channels** — full/partial (index range `1-50`), reverse
  order, skip already downloaded (archive), keyword / min-length / min-views /
  uploaded-after filters; works with `/channel/`, `/user/`, `/c/`, `@handle`
- 🔍 **Built-in YouTube Search** — search from inside the app, then download
  straight from the results
- 🧾 **Batch Download** — paste a list of URLs, all queued automatically
- 📎 **Clipboard Detection** — pasting a link anywhere shows a one-click
  download suggestion
- 🔔 **Desktop Notifications** — get notified when a download completes
- ⚡ **Concurrent Downloads** — 1–6 parallel downloads with
  pause / resume / retry / cancel
- 📊 **Real-time Progress** — live speed, ETA, and percentage per download
- 🕘 **Persistent Download History** — SQLite-backed status and progress across restarts
- ♻️ **Recovery Actions** — filter history, retry interrupted/failed tasks, open existing output files, and remove history records without deleting media
- 🛑 **Duplicate Download Guard** — warns before the same URL is started twice while its task is active; URL query strings are preserved to avoid merging distinct signed links
- 🎨 **Modern Dark/Light UI** — smooth interface with hover effects
- 📁 **Custom Save Location**, custom filename templates, per-download folder
  naming
- 🛡 **Extras** — proxy support, download speed limit, cookies file for
  logged-in sites, `archive` skip of already-downloaded files

## 🚀 Installation

### Option A — Prebuilt Windows app (recommended)
1. Download the latest release zip (`HikmahYT-v6.1.0-win64.zip`) from the
   [Releases](https://github.com/mdabusaleh1/HikmahYT/releases) page.
2. Extract the zip anywhere (e.g. `C:\Programs\HikmahYT` or your Desktop).
3. Run `HikmahYT.exe`. No Python or other software is required.

> First launch may show a Windows SmartScreen warning (the app is not
> code-signed). Click **More info → Run anyway** — it appears only once.

### Option B — Run from source
```bash
git clone https://github.com/mdabusaleh1/HikmahYT.git
cd HikmahYT
python -m pip install -r requirements.txt
python main.py
```

## 🎯 How to Use

### Download a video
1. Open the app — the **Home** page is shown.
2. Paste any video URL (YouTube, Facebook, TikTok, Instagram, X/Twitter,
   Twitch, Vimeo, Telegram, etc.) into the box — a clipboard link is suggested
   automatically.
3. Click **Analyze** — the app fetches the title, thumbnail, duration, views
   and all available formats.
4. Pick a format:
   - ⚡ **Best Quality (Auto)** — fastest choice
   - 🎬 a specific resolution (**144p → 8K**) — shows file size and fps
   - 🎵 an audio-only option (e.g. MP3 320 kbps)
5. Tune the **advanced options bar**: video codec, container, audio codec,
   subtitles (language + format + embed), thumbnail, metadata, HDR, 60fps and
   JSON export.
6. Click **Download Now**. A progress card shows speed, ETA and percentage.
7. When it finishes, you get a desktop notification and the file is saved to
   your download folder (default `~/Downloads/HikmahYT`).

### Search YouTube
1. On the **Home** page toggle **🔍 Search**.
2. Type a query and hit Enter — results appear with title, channel and length.
3. Click **Download** on any result (or **Info** to preview it first).

### Batch download
1. Click **Batch** on the Home page.
2. Paste multiple URLs (one per line) and click **Start Batch Download**.
3. Each valid URL is fetched and queued with the current format settings.

### Download a playlist / channel
1. Click **Playlist** in the sidebar (or paste a playlist/channel URL on the
   Home page — it is detected automatically).
2. Paste the URL and click **Load Playlist**.
3. Use **Select All** / **Deselect All** or toggle individual videos.
4. Open **Advanced** to filter: index range, title keyword, minimum length,
   uploaded after, reverse order, or skip already downloaded.
5. Choose a format and click **Download N Videos**. Files are saved in a
   subfolder named after the playlist.

### Change where files are saved
- **Settings** → **Download Location** → **Change**. Applies to all downloads.

### Concurrency, speed & proxy
- **Settings** → **Concurrent Downloads** (1–6), **Speed Limit** (KB/s) and
  **Proxy** — apply immediately.

### Switch theme
- **Settings** → **Theme Mode** → `Dark`, `Light`, or `System`.

### View downloads and recover tasks
- The **Downloads** page lists finished files and a persistent history panel.
- Filter history by status, retry interrupted/failed tasks, open existing output files, or remove a history record. Removing history does not delete the downloaded media.
- Interrupted tasks are not automatically restarted; use **Retry** so you stay in control. Whether a partial file resumes depends on the source and yt-dlp's support.
- Starting the exact same URL while it is already active triggers a warning. The check is intentionally conservative and does not try to infer equivalence between different URL forms.

## 📦 Build (Windows)

Building from source requires Python 3.10+. PyInstaller is installed from `requirements-build.txt`.

```bash
build.bat
```

Or manually:

```bash
python -m pip install -r requirements.txt -r requirements-build.txt
python -m PyInstaller --noconfirm --clean HikmahYT.spec
```

The executable is written to `dist\HikmahYT\HikmahYT.exe` and packaged as
`dist\HikmahYT-v6.1.0-win64.zip`. The build bundles yt-dlp (with all
extractors), an ffmpeg binary (via imageio-ffmpeg), and pycryptodomex for
reliable YouTube signature deciphering — no runtime dependencies required.

> **Note:** the exe needs the `_internal` folder beside it. Keep the whole
> `dist\HikmahYT` folder together (or use the zip). The `HikmahYT.exe` under
> the intermediate `build\` folder is NOT runnable — always run from `dist`.

## 🛠 Troubleshooting

| Problem | Fix |
|---|---|
| "Windows protected your PC" on first run | **More info → Run anyway** (unsigned app; appears once) |
| "The specified module could not be found" | You launched the wrong exe or moved `HikmahYT.exe` without its `_internal` folder. Run from the extracted folder. |
| Downloads keep failing / site requires login | Add your **cookies file** in Settings, or run from source and `python -m pip install -U yt-dlp` for the latest extractors. |
| Low-quality or missing resolution | Pick ⚡ **Best Quality** — some sites only expose what the player offers. |
| "ffmpeg is required..." error | The build bundles ffmpeg; if running from source, install `imageio-ffmpeg` (already in `requirements.txt`). |
| Video + audio won't merge | Make sure ffmpeg is found; use a combined format (⚡ Best Quality) as fallback. |
| DRM/paid content (Netflix, Spotify...) | Not supported — such sites encrypt streams by design. |

## ⚠️ Legal Notice

Only download content you have the right to, and respect each site's Terms of
Service and the copyright laws of your country.

## 🤝 License

[MIT](LICENSE)

## Phase 1 — Critical reliability fixes

- Register download workers before starting them and prevent duplicate workers for a task.
- Make pause/resume/retry/cancel transitions safer when a worker is still shutting down.
- Wake queued workers when cancelling tasks so they do not wait indefinitely for a concurrency slot.
- Apply playlist format fallback attempts and treat non-zero yt-dlp return codes as failures.
- Keep metadata embedding independent from thumbnail download/embedding options.
- Add regression tests under `tests/` (`python -m unittest discover -s tests -v`).

The source was syntax-checked and the isolated regression tests passed in the development environment. A live download / Windows executable build still needs to be tested in an environment with the project dependencies installed.

## Phase 2 — UI and Progress Stability

- Engine callbacks are dispatched through a thread-safe queue and processed on Tk's main thread.
- Closing the application marks the UI as closing, cancels active engine tasks, and stops event polling.
- Progress values are normalized and clamped to the 0–100% range; unknown or malformed byte counts are handled safely.
- Regression tests cover progress clamping and unknown-size downloads.

Run tests with:

```bash
python -m unittest discover -s tests -v
```


## Phase 3 — Download history persistence

- Download metadata and lifecycle status are stored in SQLite in the user's application-data directory (`%LOCALAPPDATA%\HikmahYT\history.sqlite3` on Windows).
- Progress is persisted in meaningful increments to avoid writing every UI tick.
- Tasks left pending/downloading/paused on a later launch are marked `interrupted`. Partial media files are left in place for yt-dlp's normal resume behavior.
- History repository API: `DownloadHistoryStore.list_all()`, `get(task_id)`, and `mark_interrupted()`.
- Recovery is currently represented in the persistent history model; a dedicated history/retry screen and automatic retry of interrupted jobs are not yet included.

Run tests with `python -m unittest discover -s tests -v`.

## Phase 4 Notes
- Added a status-filterable persistent history panel to the Downloads page.
- Added Retry for saved interrupted/failed/cancelled tasks using persisted download options.
- Added Open for existing output files and Remove for history-only deletion.
- Added history repository delete/clear operations and regression tests.
- Recovery is user-triggered; automatic resume is intentionally not enabled because source support for partial-file continuation varies.

## Phase 6 — Download recovery and output verification

- Explicitly enables yt-dlp continuation and avoids overwriting existing files, preserving partial `.part` files for supported resume flows.
- Adds a small number of file-access retries for transient filesystem contention.
- Before the UI reports a task as completed, a named output must exist, be a regular file, and have non-zero size. Missing/empty outputs are recorded as errors instead of false successes.
- Verification never deletes partial files; recovery remains user-triggered from History because automatic resume support varies by site and format.
- Added isolated tests for valid, missing, empty, directory, and unspecified output paths.

Run `python -m unittest discover -s tests -v` to execute the regression suite. Live-site downloads and Windows executable packaging still require environment-level validation.


## Phase 7 — Windows release preparation

- Synchronized the application version, Windows executable version metadata, build script, CI workflow, README, and release archive name at `6.1.0`.
- Separated PyInstaller build dependencies from runtime/source dependencies.
- CI runs Python compilation, regression tests, and release configuration checks before building the Windows package.
- Run `python scripts/check_release_config.py` locally to catch release version/artifact-name drift.
- A successful source test run does not replace testing the packaged app on a clean Windows machine.


## Phase 8 — Release artifact QA

- Added `scripts/verify_release_artifact.py` to validate the distributable ZIP's CRC, root executable, `_internal` runtime folder, bundled FFmpeg executable, and archive paths.
- GitHub Actions runs the artifact verifier after the Windows package is created; a malformed or incomplete ZIP now fails the workflow before publishing.
- Added regression tests using synthetic ZIP files for missing files, missing FFmpeg, missing archives, and unsafe paths.
- This automated check validates package structure only. A clean-Windows launch, real URL downloads, audio extraction, playlist, pause/resume/cancel, and history recovery still require manual integration testing.

### Manual release smoke-test checklist

Use a clean, supported Windows machine or VM and the extracted release ZIP. Check each item and record the Windows version, Python availability (should not be required), app version, and result.

- [ ] Extract the ZIP and launch `HikmahYT.exe` without installing Python.
- [ ] Confirm the Home page opens without a missing-module or missing-DLL error.
- [ ] Analyze a public video URL and verify title, duration, thumbnail, and available formats.
- [ ] Download one short video; verify the resulting file exists and plays.
- [ ] Download audio-only and confirm the output audio plays.
- [ ] Test a short playlist or two-item batch; verify per-item statuses and outputs.
- [ ] Pause/resume and cancel a longer download; confirm status and output behavior.
- [ ] Close and reopen the app; confirm history is retained and an interrupted item can be retried.
- [ ] Test a URL requiring FFmpeg and confirm merge/conversion succeeds.
- [ ] Confirm the app remains responsive during analysis, download, and shutdown.

Do not publish a release as fully verified until the manual checks above have been run on Windows.

## Phase 9 — Mocked engine integration QA

- Added mocked integration tests that exercise the real engine orchestration
  without making network requests or downloading copyrighted media.
- Tests cover video option construction, non-zero yt-dlp exit-code fallback,
  terminal failure reporting, playlist index selection, and playlist range
  precedence.
- Run `python -m unittest discover -s tests -v` before building a release.
- These tests do not replace a live Windows smoke test: validate EXE startup,
  a permitted test URL, FFmpeg merging, pause/resume/cancel, and recovery on a
  clean Windows machine before publishing a release.

## Phase 10 — Runtime diagnostics and release triage

- Added `scripts/diagnose_runtime.py` to report Python/platform details, required package availability, FFmpeg discovery, and download-folder write access.
- The diagnostic can print a report or save JSON with `python scripts/diagnose_runtime.py --json runtime-diagnostics.json`.
- Added isolated tests for healthy/missing-dependency reports and writable-directory checks.
- The script performs no network requests or downloads. Review the JSON report before sharing because it includes the local platform and Python executable path.
- A passing diagnostic checks the current Python environment only; it does not certify the packaged EXE, GUI startup, or live media downloads. Windows clean-machine QA remains required.

Run all automated tests with `python -m unittest discover -s tests -v`.
